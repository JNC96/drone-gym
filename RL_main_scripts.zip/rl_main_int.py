from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import os

# disable tensorforce log messages; too annoying
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import tensorforce
import gym
import gym_drone
import argparse
import importlib
import json
import logging
import os
import time
import sys

from tensorforce.agents import Agent
from tensorforce.execution import Runner
from tensorforce.environments import Environment
from tensorforce import util

from gym.envs.registration import registry, register, make, spec
from gym import envs, wrappers, logger, spaces

from datetime import datetime

try:
    # Capirca uses Google's abseil-py library, which uses a Google-specific
    # wrapper for logging. That wrapper will write a warning to sys.stderr if
    # the Google command-line flags library has not been initialized.
    #
    # https://github.com/abseil/abseil-py/blob/pypi-v0.7.1/absl/logging/__init__.py#L819-L825
    #
    # This is not right behavior for Python code that is invoked outside of a
    # Google-authored main program. Use knowledge of abseil-py to disable that
    # warning; ignore and continue if something goes wrong.
    import absl.logging

    # https://github.com/abseil/abseil-py/issues/99
    logging.root.removeHandler(absl.logging._absl_handler)
    # https://github.com/abseil/abseil-py/issues/102
    absl.logging._warn_preinit_stderr = False
except Exception:
    pass


dt = datetime.now()
dtstr = dt.strftime("%d_%m_%Y__%H-%M-%S")
fname = 'C:/Users/jar-b/Desktop/tmp/' + dtstr + '.log'
logging.basicConfig(filename=fname, level=logging.DEBUG, format='%(message)s')

"""
class WrappedEnv(OpenAIGym):

    def __init__(self, gym, visualise=False):
        self.gym=gym
        self.visualise=visualise

    def execute(self, action):
        #if self.visualise:
        #    self.gym.render()

        action = agent.act(obs, reward, done)
        obs, reward, done, _ = gym.step(action)
"""

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=None)
    parser.add_argument('env_id', nargs='?', default='drone-v0', help='Select the environment to run')
    args = parser.parse_args()

    # You can set the level to logger.DEBUG or logger.WARN if you
    # want to change the amount of output.
    logger.set_level(logger.INFO)

    # Make the environment (wrapper for gym)
    env = Environment.create(environment='gym', level='drone-v0')

    

    # You provide the directory to write to (can be an existing
    # directory, including one with existing data -- all monitor files
    # will be namespaced). You can also dump to a tempdir if you'd
    # like: tempfile.mkdtemp().
    outdir = '/tmp/random-agent-results'

    # Macro Def

    batch_size = 20
    #episode_count = 20
    episode_batch = 20
    max_timestep_per_ep = 50

    # Monitor tracks statistics.
    #env = wrappers.Monitor(env, directory=outdir, force=True)

    #env.seed(0)

    # List to store rewards per timestep.
    reward_list = []

    reward_averager = []

    # List to store average rewards (to watch for increase)
    avg_reward = []

    # AGENT DEFINITION

    agent = Agent.create(
        agent='ppo', environment=env,
        # Automatically configured network
        network='auto',
        # Optimization
        batch_size=10, update_frequency=2, learning_rate=1e-3, subsampling_fraction=0.2,
        optimization_steps=5,
        # Reward estimation
        likelihood_ratio_clipping=0.2, discount=0.99, estimate_terminal=False,
        # Critic
        critic_network='auto',
        critic_optimizer=dict(optimizer='adam', multi_step=10, learning_rate=1e-3),
        # Preprocessing
        preprocessing=None,
        # Exploration
        exploration=0.0, variable_noise=0.0,
        # Regularization
        l2_regularization=0.0, entropy_regularization=0.0,
        # TensorFlow etc
        name='agent', device=None, parallel_interactions=1, seed=None, execution=None, saver=None,
        summarizer=dict(
            directory="D:\summ",
            labels="all"
            ),
        recorder=None
    )

    # Runner init

    #savdir = "D:\modsav"
    #agent.restore(savdir)
    
    runner = Runner(agent=agent, environment=env)

    # Start the runner
    runner.run(num_episodes=1750)

    # Tuner
    
        
    #agent.save(savdir)
    #runner.close()
    

    
            
    # Close the env and write monitor result info to disk
    env.close()
    #print(datetime.now())
    #logging.shutdown() # release file handlers for logging

    
